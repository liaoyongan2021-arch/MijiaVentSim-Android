package com.liaoyongan.mijiaventsim;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

import java.util.ArrayList;
import java.util.Locale;

public class SimulationView extends View {
    public interface StateListener { void onState(double time, double pollutant); }

    private static final int NX = 120, NY = 80, N = NX * NY;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap fieldBitmap = Bitmap.createBitmap(NX, NY, Bitmap.Config.ARGB_8888);
    private final int[] pixels = new int[N];
    private final float[] c = new float[N], nextC = new float[N];
    private final float[] u = new float[N], v = new float[N];
    private final float[] nextU = new float[N], nextV = new float[N];
    private final boolean[] inside = new boolean[N];
    private final boolean[] wall = new boolean[N], furniture = new boolean[N];
    private final boolean[] window = new boolean[N], roomDoor = new boolean[N], toiletDoor = new boolean[N];
    private final ArrayList<Float> historyT = new ArrayList<>(), historyP = new ArrayList<>();
    private final ScaleGestureDetector scaleDetector;

    private StateListener listener;
    private boolean running = false, roomDoorOpen = false, toiletDoorOpen = true;
    private boolean oscillating = true;
    private int displayMode = 0, environmentMode = 0, fanPower = 70;
    private float fanX = 63, fanY = 48, fanAngle = 0;
    private float time = 0, pollutantPercent = 100;
    private float zoom = 1f, panX = 0, panY = 0;
    private float lastMultiX, lastMultiY;
    private int touchStartX, touchStartY;
    private String tool = "FAN";

    private final Runnable animator = new Runnable() {
        @Override public void run() {
            if (running) {
                for (int k = 0; k < 3; k++) step();
                invalidate();
                if (listener != null) listener.onState(time, pollutantPercent);
            }
            postOnAnimation(this);
        }
    };

    public SimulationView(Context context) {
        super(context);
        setBackgroundColor(Color.WHITE);
        textPaint.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                zoom = clamp(zoom * detector.getScaleFactor(), 0.55f, 4.0f);
                invalidate();
                return true;
            }
        });
        defaultLayout();
        post(animator);
    }

    public void setStateListener(StateListener listener) { this.listener = listener; }
    public void setTool(String tool) { this.tool = tool; }
    public void setDisplayMode(int mode) { displayMode = mode; invalidate(); }
    public void setFanPower(int power) { fanPower = Math.max(1, Math.min(100, power)); }
    public void setFanAngle(int degree) { fanAngle = degree; invalidate(); }
    public void setOscillating(boolean value) { oscillating = value; }
    public void setEnvironmentMode(int value) { environmentMode = value; }
    public void setRoomDoorOpen(boolean value) { roomDoorOpen = value; invalidate(); }
    public void setToiletDoorOpen(boolean value) { toiletDoorOpen = value; invalidate(); }
    public boolean isRunning() { return running; }
    public void setRunning(boolean value) { running = value; }
    public void zoomBy(float factor) { zoom = clamp(zoom * factor, 0.55f, 4.0f); invalidate(); }
    public void fitView() { zoom = 1f; panX = panY = 0; invalidate(); }

    private int idx(int x, int y) { return y * NX + x; }
    private float clamp(float x, float lo, float hi) { return Math.max(lo, Math.min(hi, x)); }

    public void defaultLayout() {
        for (int i = 0; i < N; i++) {
            inside[i] = wall[i] = furniture[i] = window[i] = roomDoor[i] = toiletDoor[i] = false;
        }
        // Irregular L-shaped apartment outline.
        for (int y = 7; y <= 72; y++) for (int x = 7; x <= 112; x++) {
            if (!(x >= 87 && y <= 22)) inside[idx(x, y)] = true;
        }
        for (int y = 1; y < NY - 1; y++) for (int x = 1; x < NX - 1; x++) {
            int i = idx(x, y);
            if (!inside[i]) continue;
            if (!inside[idx(x - 1, y)] || !inside[idx(x + 1, y)] ||
                    !inside[idx(x, y - 1)] || !inside[idx(x, y + 1)]) wall[i] = true;
        }
        // Toilet walls and its normally open door.
        for (int y = 8; y <= 31; y++) wall[idx(34, y)] = true;
        for (int x = 8; x <= 34; x++) wall[idx(x, 31)] = true;
        for (int y = 19; y <= 25; y++) toiletDoor[idx(34, y)] = true;
        // One exterior window and one normally closed room door.
        for (int y = 38; y <= 53; y++) window[idx(112, y)] = true;
        for (int x = 53; x <= 65; x++) roomDoor[idx(x, 72)] = true;
        // Example solid furniture.
        for (int y = 48; y <= 60; y++) for (int x = 18; x <= 35; x++) furniture[idx(x, y)] = true;
        for (int y = 34; y <= 43; y++) for (int x = 73; x <= 91; x++) furniture[idx(x, y)] = true;
        fanX = 62; fanY = 54; fanAngle = 12;
        resetSimulation();
    }

    private boolean solid(int i) {
        if (!inside[i]) return true;
        if (furniture[i]) return true;
        if (window[i]) return false;
        if (roomDoor[i]) return !roomDoorOpen;
        if (toiletDoor[i]) return !toiletDoorOpen;
        return wall[i];
    }

    public void resetSimulation() {
        running = false;
        time = 0;
        historyT.clear(); historyP.clear();
        for (int i = 0; i < N; i++) {
            u[i] = v[i] = 0;
            c[i] = inside[i] && !solid(i) ? 1f : 0f;
        }
        pollutantPercent = 100;
        historyT.add(0f); historyP.add(100f);
        if (listener != null) listener.onState(time, pollutantPercent);
        invalidate();
    }

    private void step() {
        float actualAngle = fanAngle;
        if (oscillating) actualAngle += 70f * triangle(time / 20f);
        float a = (float) Math.toRadians(actualAngle);
        float fdx = (float) Math.cos(a), fdy = -(float) Math.sin(a);
        float power = (float) Math.pow(fanPower / 100f, 0.7);
        float wind = environmentMode == 1 ? 0.025f : environmentMode == 2 ? 0.009f : 0f;

        for (int y = 1; y < NY - 1; y++) for (int x = 1; x < NX - 1; x++) {
            int i = idx(x, y);
            if (solid(i)) { nextU[i] = nextV[i] = nextC[i] = 0; continue; }
            int l = idx(x - 1, y), r = idx(x + 1, y), t = idx(x, y - 1), b = idx(x, y + 1);
            float lapU = neighbor(u, l, i) + neighbor(u, r, i) + neighbor(u, t, i) + neighbor(u, b, i) - 4 * u[i];
            float lapV = neighbor(v, l, i) + neighbor(v, r, i) + neighbor(v, t, i) + neighbor(v, b, i) - 4 * v[i];
            float rx = x - fanX, ry = y - fanY;
            float axial = rx * fdx + ry * fdy;
            float lateral = -rx * fdy + ry * fdx;
            float envelope = (float) Math.exp(-(axial * axial / 85f + lateral * lateral / 9f));
            if (Math.abs(axial) > 15) envelope = 0;
            nextU[i] = clamp(0.985f * u[i] + 0.13f * lapU + 0.018f * power * envelope * fdx + wind, -0.18f, 0.18f);
            nextV[i] = clamp(0.985f * v[i] + 0.13f * lapV + 0.018f * power * envelope * fdy, -0.18f, 0.18f);

            float cc = c[i];
            float cl = neighbor(c, l, i), cr = neighbor(c, r, i), ct = neighbor(c, t, i), cb = neighbor(c, b, i);
            float dcx = nextU[i] >= 0 ? cc - cl : cr - cc;
            float dcy = nextV[i] >= 0 ? cc - ct : cb - cc;
            float lapC = cl + cr + ct + cb - 4 * cc;
            nextC[i] = clamp(cc - nextU[i] * dcx - nextV[i] * dcy + 0.035f * lapC, 0, 1);
            if (window[i] || (roomDoor[i] && roomDoorOpen)) nextC[i] *= 0.12f;
        }
        System.arraycopy(nextU, 0, u, 0, N);
        System.arraycopy(nextV, 0, v, 0, N);
        System.arraycopy(nextC, 0, c, 0, N);
        time += 0.25f;
        float mass = 0; int count = 0;
        for (int i = 0; i < N; i++) if (inside[i] && !solid(i)) { mass += c[i]; count++; }
        pollutantPercent = count == 0 ? 0 : 100f * mass / count;
        if (historyT.isEmpty() || time - historyT.get(historyT.size() - 1) >= 1f) {
            historyT.add(time); historyP.add(pollutantPercent);
        }
    }

    private float neighbor(float[] field, int j, int center) { return solid(j) ? field[center] : field[j]; }
    private float triangle(float p) { p -= (float) Math.floor(p); return 1f - 4f * Math.abs(p - 0.5f); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (displayMode == 3) { drawCurve(canvas); return; }
        updatePixels();
        fieldBitmap.setPixels(pixels, 0, NX, 0, 0, NX, NY);
        float base = Math.min((getWidth() - 34f) / NX, (getHeight() - 34f) / NY);
        float scale = base * zoom;
        canvas.save();
        canvas.translate(getWidth() / 2f + panX, getHeight() / 2f + panY);
        canvas.scale(scale, scale);
        paint.setFilterBitmap(false);
        canvas.drawBitmap(fieldBitmap, -NX / 2f, -NY / 2f, paint);
        if (displayMode == 2) drawVectors(canvas);
        drawFan(canvas);
        canvas.restore();
        drawOverlay(canvas);
    }

    private void updatePixels() {
        for (int i = 0; i < N; i++) {
            if (!inside[i]) { pixels[i] = Color.rgb(224, 233, 237); continue; }
            if (furniture[i]) { pixels[i] = Color.rgb(82, 88, 92); continue; }
            if (wall[i] && !window[i] && !roomDoor[i] && !toiletDoor[i]) { pixels[i] = Color.rgb(30, 36, 40); continue; }
            if (window[i]) { pixels[i] = Color.rgb(34, 188, 216); continue; }
            if (roomDoor[i]) { pixels[i] = roomDoorOpen ? Color.rgb(65, 180, 92) : Color.rgb(181, 82, 54); continue; }
            if (toiletDoor[i]) { pixels[i] = toiletDoorOpen ? Color.rgb(65, 180, 92) : Color.rgb(181, 82, 54); continue; }
            if (displayMode == 0) pixels[i] = pollutantColor(c[i]);
            else pixels[i] = speedColor((float) Math.hypot(u[i], v[i]));
        }
    }

    private int pollutantColor(float q) {
        q = clamp(q, 0, 1);
        int r = (int) (255 * clamp(2.15f * q, 0, 1));
        int g = (int) (255 * clamp(1.6f - 2.0f * Math.abs(q - 0.52f), 0.08f, 1));
        int b = (int) (255 * clamp(2.0f * (1 - q), 0, 1));
        return Color.rgb(r, g, b);
    }

    private int speedColor(float q) {
        q = clamp(q / 0.14f, 0, 1);
        return Color.rgb((int) (255 * clamp(1.8f * q, 0, 1)),
                (int) (255 * clamp(1.5f - 2f * Math.abs(q - .55f), .05f, 1)),
                (int) (255 * clamp(1.6f * (1 - q), 0, 1)));
    }

    private void drawVectors(Canvas canvas) {
        paint.setColor(Color.rgb(14, 48, 70)); paint.setStrokeWidth(.35f);
        for (int y = 6; y < NY - 5; y += 6) for (int x = 6; x < NX - 5; x += 6) {
            int i = idx(x, y); if (solid(i)) continue;
            float ex = x + u[i] * 40f, ey = y + v[i] * 40f;
            canvas.drawLine(x - NX / 2f, y - NY / 2f, ex - NX / 2f, ey - NY / 2f, paint);
            canvas.drawCircle(ex - NX / 2f, ey - NY / 2f, .45f, paint);
        }
    }

    private void drawFan(Canvas canvas) {
        float a = (float) Math.toRadians(fanAngle);
        float x = fanX - NX / 2f, y = fanY - NY / 2f;
        paint.setColor(Color.WHITE); paint.setStyle(Paint.Style.FILL); canvas.drawCircle(x, y, 1.8f, paint);
        paint.setColor(Color.rgb(36, 74, 96)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(.5f); canvas.drawCircle(x, y, 1.8f, paint);
        paint.setColor(Color.rgb(255, 112, 24)); paint.setStrokeWidth(.8f);
        canvas.drawLine(x, y, x + 7 * (float) Math.cos(a), y - 7 * (float) Math.sin(a), paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawOverlay(Canvas canvas) {
        textPaint.setColor(Color.argb(225, 255, 255, 255));
        canvas.drawRoundRect(new RectF(14, 14, 260, 74), 10, 10, textPaint);
        textPaint.setColor(Color.rgb(40, 57, 67)); textPaint.setTextSize(18 * getResources().getDisplayMetrics().scaledDensity);
        canvas.drawText(String.format(Locale.CHINA, "t = %.1f s", time), 26, 40, textPaint);
        textPaint.setTextSize(15 * getResources().getDisplayMetrics().scaledDensity);
        canvas.drawText(String.format(Locale.CHINA, "污染物剩余 %.1f%%", pollutantPercent), 26, 65, textPaint);
    }

    private void drawCurve(Canvas canvas) {
        canvas.drawColor(Color.WHITE);
        float l = 90, r = getWidth() - 40, t = 75, b = getHeight() - 70;
        textPaint.setColor(Color.rgb(35, 52, 62)); textPaint.setTextSize(22 * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setTextAlign(Paint.Align.CENTER); canvas.drawText("室内污染物随时间的下降曲线", getWidth() / 2f, 42, textPaint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1);
        for (int pct = 0; pct <= 100; pct += 20) {
            float y = b - pct / 100f * (b - t);
            paint.setColor(Color.rgb(222, 228, 231)); canvas.drawLine(l, y, r, y, paint);
            textPaint.setTextAlign(Paint.Align.RIGHT); textPaint.setTextSize(13 * getResources().getDisplayMetrics().scaledDensity);
            textPaint.setColor(Color.DKGRAY); canvas.drawText(String.valueOf(pct), l - 12, y + 5, textPaint);
        }
        paint.setColor(Color.rgb(52, 74, 86)); paint.setStrokeWidth(2); canvas.drawLine(l, t, l, b, paint); canvas.drawLine(l, b, r, b, paint);
        float tmax = Math.max(60, (float) Math.ceil(Math.max(time, 1) / 60f) * 60f);
        Path path = new Path();
        for (int i = 0; i < historyT.size(); i++) {
            float x = l + Math.min(1, historyT.get(i) / tmax) * (r - l);
            float y = b - historyP.get(i) / 100f * (b - t);
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        paint.setColor(Color.rgb(210, 67, 49)); paint.setStrokeWidth(4); canvas.drawPath(path, paint);
        textPaint.setTextAlign(Paint.Align.CENTER); textPaint.setTextSize(14 * getResources().getDisplayMetrics().scaledDensity);
        textPaint.setColor(Color.DKGRAY); canvas.drawText("等效时间 (s)", (l + r) / 2, getHeight() - 22, textPaint);
        textPaint.setTextAlign(Paint.Align.LEFT); canvas.drawText(String.format(Locale.CHINA, "当前 %.2f%%", pollutantPercent), r - 160, t + 28, textPaint);
        paint.setStyle(Paint.Style.FILL);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        if (event.getPointerCount() >= 2) {
            float mx = (event.getX(0) + event.getX(1)) / 2f;
            float my = (event.getY(0) + event.getY(1)) / 2f;
            if (event.getActionMasked() == MotionEvent.ACTION_POINTER_DOWN) { lastMultiX = mx; lastMultiY = my; }
            else if (event.getActionMasked() == MotionEvent.ACTION_MOVE && !scaleDetector.isInProgress()) {
                panX += mx - lastMultiX; panY += my - lastMultiY; lastMultiX = mx; lastMultiY = my; invalidate();
            }
            return true;
        }
        int[] cell = screenToCell(event.getX(), event.getY());
        int x = cell[0], y = cell[1];
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            touchStartX = x; touchStartY = y;
            if (tool.equals("FAN")) { fanX = x; fanY = y; }
            else paintTool(x, y);
            invalidate(); return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_MOVE) {
            if (tool.equals("FAN")) {
                fanAngle = (float) Math.toDegrees(Math.atan2(touchStartY - y, x - touchStartX));
            } else paintTool(x, y);
            invalidate(); return true;
        }
        return true;
    }

    private int[] screenToCell(float sx, float sy) {
        float base = Math.min((getWidth() - 34f) / NX, (getHeight() - 34f) / NY);
        float scale = base * zoom;
        int x = Math.round((sx - getWidth() / 2f - panX) / scale + NX / 2f);
        int y = Math.round((sy - getHeight() / 2f - panY) / scale + NY / 2f);
        return new int[]{Math.max(1, Math.min(NX - 2, x)), Math.max(1, Math.min(NY - 2, y))};
    }

    private void paintTool(int x, int y) {
        int radius = tool.equals("FURNITURE") ? 3 : 1;
        for (int yy = y - radius; yy <= y + radius; yy++) for (int xx = x - radius; xx <= x + radius; xx++) {
            if (xx <= 0 || yy <= 0 || xx >= NX - 1 || yy >= NY - 1) continue;
            int i = idx(xx, yy); inside[i] = true;
            if (tool.equals("ERASER")) wall[i] = furniture[i] = window[i] = roomDoor[i] = toiletDoor[i] = false;
            else if (tool.equals("WALL")) { wall[i] = true; window[i] = roomDoor[i] = toiletDoor[i] = false; }
            else if (tool.equals("FURNITURE")) furniture[i] = true;
            else if (tool.equals("WINDOW")) { wall[i] = true; window[i] = true; }
            else if (tool.equals("ROOM_DOOR")) { wall[i] = true; roomDoor[i] = true; }
            else if (tool.equals("TOILET_DOOR")) { wall[i] = true; toiletDoor[i] = true; }
        }
    }

    public Bitmap exportBitmap() {
        Bitmap bitmap = Bitmap.createBitmap(Math.max(1, getWidth()), Math.max(1, getHeight()), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap); draw(canvas); return bitmap;
    }
}
