package com.liaoyongan.mijiaventsim;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import java.util.*;

public class SimulationView extends View {
    public interface StateListener { void onState(double time, double pollutant); }
    private static final int NX=140, NY=100, N=NX*NY;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG), textPaint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Bitmap fieldBitmap=Bitmap.createBitmap(NX,NY,Bitmap.Config.ARGB_8888);
    private final int[] pixels=new int[N];
    private final boolean[] inside=new boolean[N],wall=new boolean[N],furniture=new boolean[N];
    private final boolean[] window=new boolean[N],roomDoor=new boolean[N],toiletDoor=new boolean[N],solid=new boolean[N];
    private final ArrayList<PointF> outlineMeters=new ArrayList<>(),outlineGrid=new ArrayList<>();
    private final ArrayList<Float> historyT=new ArrayList<>(),historyP=new ArrayList<>();
    private final ScaleGestureDetector scaleDetector;
    private final LbmSolver solver=new LbmSolver(NX,NY);
    private StateListener listener;
    private boolean running,roomDoorOpen,toiletDoorOpen=true,dragging;
    private int displayMode,startX,startY,currentX,currentY;
    private float zoom=1,panX,panY,lastMultiX,lastMultiY;
    private String tool="FAN";

    private final Runnable animator=new Runnable(){@Override public void run(){
        if(running){solver.step(2);double p=solver.pollutantPercent();
            if(historyT.isEmpty()||solver.timeSeconds-historyT.get(historyT.size()-1)>=1){historyT.add((float)solver.timeSeconds);historyP.add((float)p);}
            if(listener!=null)listener.onState(solver.timeSeconds,p);invalidate();}
        postOnAnimation(this);
    }};

    public SimulationView(Context context){super(context);setBackgroundColor(Color.WHITE);
        textPaint.setTypeface(Typeface.create("sans",Typeface.NORMAL));
        scaleDetector=new ScaleGestureDetector(context,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScale(ScaleGestureDetector d){zoom=clamp(zoom*d.getScaleFactor(),.5f,4f);invalidate();return true;}});
        defaultLayout();post(animator);
    }
    public void setStateListener(StateListener l){listener=l;} public void setTool(String v){tool=v;}
    public void setDisplayMode(int v){displayMode=v;invalidate();} public void setFanPower(int v){solver.fanLevel=v;}
    public void setFanAngle(int v){solver.fanAngle=v;invalidate();} public void setOscillating(boolean v){solver.oscillating=v;}
    public void setEnvironmentMode(int v){solver.environmentMode=v;} public void setOutdoorSpeed(double v){solver.outdoorSpeed=Math.max(0,v);}
    public void setOutdoorAngle(double v){solver.outdoorAngle=v;} public boolean isRunning(){return running;}
    public void setRunning(boolean v){running=v;} public void zoomBy(float v){zoom=clamp(zoom*v,.5f,4f);invalidate();}
    public void fitView(){zoom=1;panX=panY=0;invalidate();}
    public void setRoomDoorOpen(boolean v){roomDoorOpen=v;resetSimulation();}
    public void setToiletDoorOpen(boolean v){toiletDoorOpen=v;resetSimulation();}
    private int id(int x,int y){return y*NX+x;} private float clamp(float x,float a,float b){return Math.max(a,Math.min(b,x));}

    public void startOutline(){running=false;outlineMeters.clear();outlineMeters.add(new PointF(0,0));
        Arrays.fill(inside,false);Arrays.fill(wall,false);Arrays.fill(window,false);Arrays.fill(roomDoor,false);
        Arrays.fill(toiletDoor,false);Arrays.fill(furniture,false);updateOutlinePreview();resetSimulation();}
    public String addOutlineSegment(String direction,float length){
        if(length<=0)return "墙长必须大于 0";if(outlineMeters.isEmpty())outlineMeters.add(new PointF(0,0));
        boolean horizontal=direction.equals("向左")||direction.equals("向右");
        if(outlineMeters.size()>=2){PointF a=outlineMeters.get(outlineMeters.size()-2),b=outlineMeters.get(outlineMeters.size()-1);
            boolean lastHorizontal=Math.abs(b.x-a.x)>Math.abs(b.y-a.y);if(horizontal==lastHorizontal)return "相邻外墙必须互相垂直";}
        PointF p=outlineMeters.get(outlineMeters.size()-1);float dx=direction.equals("向右")?length:direction.equals("向左")?-length:0;
        float dy=direction.equals("向上")?length:direction.equals("向下")?-length:0;
        outlineMeters.add(new PointF(p.x+dx,p.y+dy));updateOutlinePreview();invalidate();
        return String.format(Locale.CHINA,"当前点：(%.2f, %.2f) m",p.x+dx,p.y+dy);
    }
    public String autoCloseOutline(){
        if(outlineMeters.size()<3)return "至少需要三段外墙";PointF first=outlineMeters.get(0),last=outlineMeters.get(outlineMeters.size()-1);
        float dx=first.x-last.x,dy=first.y-last.y;PointF prev=outlineMeters.get(outlineMeters.size()-2);
        boolean lastHorizontal=Math.abs(last.x-prev.x)>Math.abs(last.y-prev.y);
        if(Math.abs(dx)>1e-4&&Math.abs(dy)>1e-4){if(lastHorizontal)outlineMeters.add(new PointF(last.x,first.y));else outlineMeters.add(new PointF(first.x,last.y));}
        else if((Math.abs(dx)>1e-4&&lastHorizontal)||(Math.abs(dy)>1e-4&&!lastHorizontal))return "最后一段与闭合边不垂直，请再添加一段墙";
        outlineMeters.add(new PointF(first.x,first.y));rasterizeOutline();resetSimulation();return "房间已闭合并生成";
    }

    public void defaultLayout(){outlineMeters.clear();
        outlineMeters.add(new PointF(0,0));outlineMeters.add(new PointF(5.5f,0));outlineMeters.add(new PointF(5.5f,2.3f));
        outlineMeters.add(new PointF(4.1f,2.3f));outlineMeters.add(new PointF(4.1f,4.2f));outlineMeters.add(new PointF(0,4.2f));outlineMeters.add(new PointF(0,0));
        Arrays.fill(furniture,false);Arrays.fill(window,false);Arrays.fill(roomDoor,false);Arrays.fill(toiletDoor,false);rasterizeOutline();
        drawMaskLine(wall,37,18,37,43,1,false);drawMaskLine(wall,15,43,37,43,1,false);drawMaskLine(toiletDoor,37,29,37,35,1,true);
        placeNearestBoundary(window,112,52,0,15);placeNearestBoundary(roomDoor,68,77,12,0);
        for(int y=60;y<=72;y++)for(int x=24;x<=39;x++)if(inside[id(x,y)])furniture[id(x,y)]=true;
        solver.fanX=73.0/(NX-1);solver.fanY=66.0/(NY-1);solver.fanAngle=10;resetSimulation();
    }
    private void rasterizeOutline(){Arrays.fill(inside,false);Arrays.fill(wall,false);outlineGrid.clear();if(outlineMeters.size()<4)return;
        float minX=Float.MAX_VALUE,maxX=-Float.MAX_VALUE,minY=Float.MAX_VALUE,maxY=-Float.MAX_VALUE;
        for(PointF p:outlineMeters){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}
        float scale=Math.min((NX-28f)/Math.max(maxX-minX,.1f),(NY-28f)/Math.max(maxY-minY,.1f)),midX=(minX+maxX)/2,midY=(minY+maxY)/2;
        for(PointF p:outlineMeters)outlineGrid.add(new PointF(NX/2f+(p.x-midX)*scale,NY/2f-(p.y-midY)*scale));
        for(int y=1;y<NY-1;y++)for(int x=1;x<NX-1;x++)inside[id(x,y)]=pointInPolygon(x+.5f,y+.5f,outlineGrid);
        boolean[] base=Arrays.copyOf(inside,N);for(int y=1;y<NY-1;y++)for(int x=1;x<NX-1;x++){int i=id(x,y);if(!base[i])continue;
            if(!base[id(x-1,y)]||!base[id(x+1,y)]||!base[id(x,y-1)]||!base[id(x,y+1)])wall[i]=true;}
        boolean[] thin=Arrays.copyOf(wall,N);for(int y=2;y<NY-2;y++)for(int x=2;x<NX-2;x++)if(thin[id(x,y)]){
            wall[id(x-1,y)]=true;wall[id(x+1,y)]=true;wall[id(x,y-1)]=true;wall[id(x,y+1)]=true;}
    }
    private void updateOutlinePreview(){outlineGrid.clear();if(outlineMeters.isEmpty())return;
        float minX=Float.MAX_VALUE,maxX=-Float.MAX_VALUE,minY=Float.MAX_VALUE,maxY=-Float.MAX_VALUE;
        for(PointF p:outlineMeters){minX=Math.min(minX,p.x);maxX=Math.max(maxX,p.x);minY=Math.min(minY,p.y);maxY=Math.max(maxY,p.y);}
        float scale=Math.min((NX-28f)/Math.max(maxX-minX,1f),(NY-28f)/Math.max(maxY-minY,1f)),midX=(minX+maxX)/2,midY=(minY+maxY)/2;
        for(PointF p:outlineMeters)outlineGrid.add(new PointF(NX/2f+(p.x-midX)*scale,NY/2f-(p.y-midY)*scale));}
    private boolean pointInPolygon(float x,float y,ArrayList<PointF> poly){boolean hit=false;for(int i=0,j=poly.size()-1;i<poly.size();j=i++){
        PointF a=poly.get(i),b=poly.get(j);if(((a.y>y)!=(b.y>y))&&x<(b.x-a.x)*(y-a.y)/(b.y-a.y)+a.x)hit=!hit;}return hit;}
    private void placeNearestBoundary(boolean[] mask,int tx,int ty,int hx,int hy){int best=-1,dist=Integer.MAX_VALUE;
        for(int y=2;y<NY-2;y++)for(int x=2;x<NX-2;x++)if(wall[id(x,y)]){int d=(x-tx)*(x-tx)+(y-ty)*(y-ty);if(d<dist){dist=d;best=id(x,y);}}
        if(best>=0){int bx=best%NX,by=best/NX;drawMaskLine(mask,bx-hx,by-hy,bx+hx,by+hy,1,true);}}
    private void rebuildSolid(){for(int i=0;i<N;i++)solid[i]=furniture[i]||(wall[i]&&!window[i]&&!(roomDoor[i]&&roomDoorOpen)&&!(toiletDoor[i]&&toiletDoorOpen));}
    public void resetSimulation(){running=false;rebuildSolid();solver.reset(solid,inside);historyT.clear();historyP.clear();historyT.add(0f);historyP.add(100f);if(listener!=null)listener.onState(0,100);invalidate();}

    @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);if(displayMode==3){drawCurve(canvas);return;}updatePixels();fieldBitmap.setPixels(pixels,0,NX,0,0,NX,NY);
        float base=Math.min((getWidth()-30f)/NX,(getHeight()-30f)/NY),s=base*zoom;canvas.save();canvas.translate(getWidth()/2f+panX,getHeight()/2f+panY);canvas.scale(s,s);
        paint.setFilterBitmap(false);canvas.drawBitmap(fieldBitmap,-NX/2f,-NY/2f,paint);if(displayMode==2)drawVectors(canvas);drawFan(canvas);drawOutlinePreview(canvas);
        if(dragging&&!tool.equals("FAN")){paint.setColor(Color.rgb(255,145,20));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.8f);
            int ex=Math.abs(currentX-startX)>=Math.abs(currentY-startY)?currentX:startX,ey=Math.abs(currentX-startX)>=Math.abs(currentY-startY)?startY:currentY;
            canvas.drawLine(startX-NX/2f,startY-NY/2f,ex-NX/2f,ey-NY/2f,paint);paint.setStyle(Paint.Style.FILL);}canvas.restore();drawOverlay(canvas);}
    private void updatePixels(){for(int i=0;i<N;i++){
        if(furniture[i])pixels[i]=Color.rgb(80,86,90);else if(wall[i]&&!window[i]&&!roomDoor[i]&&!toiletDoor[i])pixels[i]=Color.rgb(29,35,39);
        else if(window[i])pixels[i]=Color.rgb(35,190,218);else if(roomDoor[i])pixels[i]=roomDoorOpen?Color.rgb(61,180,90):Color.rgb(183,81,53);
        else if(toiletDoor[i])pixels[i]=toiletDoorOpen?Color.rgb(61,180,90):Color.rgb(183,81,53);
        else pixels[i]=displayMode==0?pollutantColor((float)solver.pollutant[i]):speedColor((float)solver.physicalSpeed(i));}}
    private int pollutantColor(float q){q=clamp(q,0,1);return Color.rgb((int)(255*clamp(2.2f*q,0,1)),(int)(255*clamp(1.8f-2f*Math.abs(q-.55f),.08f,1)),(int)(255*clamp(2f*(1-q),0,1)));}
    private int speedColor(float q){q=clamp(q/2.2f,0,1);return Color.rgb((int)(255*clamp(2f*q,0,1)),(int)(255*clamp(1.7f-2.2f*Math.abs(q-.5f),0,1)),(int)(255*clamp(1.7f*(1-q),0,1)));}
    private void drawVectors(Canvas c){paint.setColor(Color.rgb(12,46,68));paint.setStrokeWidth(.35f);for(int y=6;y<NY-5;y+=7)for(int x=6;x<NX-5;x+=7){int i=id(x,y);if(solid[i])continue;double m=Math.hypot(solver.ux[i],solver.uy[i]);if(m<.001)continue;float f=(float)Math.min(150,10/m),ex=(float)(x+solver.ux[i]*f),ey=(float)(y+solver.uy[i]*f);c.drawLine(x-NX/2f,y-NY/2f,ex-NX/2f,ey-NY/2f,paint);c.drawCircle(ex-NX/2f,ey-NY/2f,.4f,paint);}}
    private void drawFan(Canvas c){float x=(float)(solver.fanX*(NX-1))-NX/2f,y=(float)(solver.fanY*(NY-1))-NY/2f,a=(float)Math.toRadians(solver.currentFanAngle());paint.setColor(Color.WHITE);c.drawCircle(x,y,1.8f,paint);paint.setColor(Color.rgb(36,74,96));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.5f);c.drawCircle(x,y,1.8f,paint);paint.setColor(Color.rgb(255,112,24));paint.setStrokeWidth(.8f);c.drawLine(x,y,x+7*(float)Math.cos(a),y-7*(float)Math.sin(a),paint);paint.setStyle(Paint.Style.FILL);}
    private void drawOutlinePreview(Canvas c){if(outlineGrid.size()<2||isOutlineClosed())return;paint.setColor(Color.rgb(244,157,0));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.8f);Path p=new Path();p.moveTo(outlineGrid.get(0).x-NX/2f,outlineGrid.get(0).y-NY/2f);for(int i=1;i<outlineGrid.size();i++)p.lineTo(outlineGrid.get(i).x-NX/2f,outlineGrid.get(i).y-NY/2f);c.drawPath(p,paint);paint.setStyle(Paint.Style.FILL);for(PointF q:outlineGrid)c.drawCircle(q.x-NX/2f,q.y-NY/2f,.8f,paint);}
    private boolean isOutlineClosed(){if(outlineMeters.size()<3)return false;PointF a=outlineMeters.get(0),b=outlineMeters.get(outlineMeters.size()-1);return Math.abs(a.x-b.x)<1e-4&&Math.abs(a.y-b.y)<1e-4;}
    private void drawOverlay(Canvas c){textPaint.setColor(Color.argb(225,255,255,255));c.drawRoundRect(new RectF(14,14,278,78),10,10,textPaint);textPaint.setColor(Color.rgb(40,57,67));textPaint.setTextSize(17*getResources().getDisplayMetrics().scaledDensity);c.drawText(String.format(Locale.CHINA,"t = %.1f s",solver.timeSeconds),25,41,textPaint);textPaint.setTextSize(14*getResources().getDisplayMetrics().scaledDensity);c.drawText(String.format(Locale.CHINA,"污染物剩余 %.1f%%",solver.pollutantPercent()),25,68,textPaint);}
    private void drawCurve(Canvas c){c.drawColor(Color.WHITE);float l=90,r=getWidth()-40,t=75,b=getHeight()-70;textPaint.setColor(Color.rgb(35,52,62));textPaint.setTextSize(22*getResources().getDisplayMetrics().scaledDensity);textPaint.setTextAlign(Paint.Align.CENTER);c.drawText("室内污染物随时间的下降曲线",getWidth()/2f,42,textPaint);paint.setStyle(Paint.Style.STROKE);for(int pct=0;pct<=100;pct+=20){float y=b-pct/100f*(b-t);paint.setColor(Color.rgb(222,228,231));c.drawLine(l,y,r,y,paint);textPaint.setTextAlign(Paint.Align.RIGHT);textPaint.setTextSize(13*getResources().getDisplayMetrics().scaledDensity);textPaint.setColor(Color.DKGRAY);c.drawText(String.valueOf(pct),l-12,y+5,textPaint);}paint.setColor(Color.rgb(52,74,86));paint.setStrokeWidth(2);c.drawLine(l,t,l,b,paint);c.drawLine(l,b,r,b,paint);float tm=Math.max(60,(float)Math.ceil(Math.max(solver.timeSeconds,1)/60)*60);Path path=new Path();for(int i=0;i<historyT.size();i++){float x=l+Math.min(1,historyT.get(i)/tm)*(r-l),y=b-historyP.get(i)/100f*(b-t);if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}paint.setColor(Color.rgb(210,67,49));paint.setStrokeWidth(4);c.drawPath(path,paint);textPaint.setTextAlign(Paint.Align.CENTER);textPaint.setTextSize(14*getResources().getDisplayMetrics().scaledDensity);textPaint.setColor(Color.DKGRAY);c.drawText("等效时间 (s)",(l+r)/2,getHeight()-22,textPaint);paint.setStyle(Paint.Style.FILL);}

    @Override public boolean onTouchEvent(MotionEvent e){scaleDetector.onTouchEvent(e);if(e.getPointerCount()>=2){float mx=(e.getX(0)+e.getX(1))/2,my=(e.getY(0)+e.getY(1))/2;if(e.getActionMasked()==MotionEvent.ACTION_POINTER_DOWN){lastMultiX=mx;lastMultiY=my;}else if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&!scaleDetector.isInProgress()){panX+=mx-lastMultiX;panY+=my-lastMultiY;lastMultiX=mx;lastMultiY=my;invalidate();}return true;}int[] p=screenToCell(e.getX(),e.getY());currentX=p[0];currentY=p[1];if(e.getActionMasked()==MotionEvent.ACTION_DOWN){startX=currentX;startY=currentY;dragging=true;if(tool.equals("FAN")){solver.fanX=startX/(double)(NX-1);solver.fanY=startY/(double)(NY-1);}invalidate();return true;}if(e.getActionMasked()==MotionEvent.ACTION_MOVE){if(tool.equals("FAN"))solver.fanAngle=Math.toDegrees(Math.atan2(startY-currentY,currentX-startX));invalidate();return true;}if(e.getActionMasked()==MotionEvent.ACTION_UP){if(!tool.equals("FAN"))finishGeometryStroke();dragging=false;invalidate();return true;}return true;}
    private int[] screenToCell(float sx,float sy){float base=Math.min((getWidth()-30f)/NX,(getHeight()-30f)/NY),s=base*zoom;int x=Math.round((sx-getWidth()/2f-panX)/s+NX/2f),y=Math.round((sy-getHeight()/2f-panY)/s+NY/2f);return new int[]{Math.max(2,Math.min(NX-3,x)),Math.max(2,Math.min(NY-3,y))};}
    private void finishGeometryStroke(){if(tool.equals("FURNITURE")){int xa=Math.min(startX,currentX),xb=Math.max(startX,currentX),ya=Math.min(startY,currentY),yb=Math.max(startY,currentY);for(int y=ya;y<=yb;y++)for(int x=xa;x<=xb;x++)if(inside[id(x,y)])furniture[id(x,y)]=true;}else{boolean h=Math.abs(currentX-startX)>=Math.abs(currentY-startY);int ex=h?currentX:startX,ey=h?startY:currentY;if(tool.equals("WALL"))drawMaskLine(wall,startX,startY,ex,ey,1,false);else if(tool.equals("ERASER"))eraseLine(startX,startY,ex,ey,2);else{boolean[] target=tool.equals("WINDOW")?window:tool.equals("ROOM_DOOR")?roomDoor:toiletDoor;drawMaskLine(target,startX,startY,ex,ey,1,true);}}resetSimulation();}
    private void drawMaskLine(boolean[] mask,int x0,int y0,int x1,int y1,int radius,boolean requireWall){int steps=Math.max(Math.abs(x1-x0),Math.abs(y1-y0));for(int k=0;k<=steps;k++){int x=Math.round(x0+(x1-x0)*k/(float)Math.max(steps,1)),y=Math.round(y0+(y1-y0)*k/(float)Math.max(steps,1));for(int yy=y-radius;yy<=y+radius;yy++)for(int xx=x-radius;xx<=x+radius;xx++)if(xx>1&&yy>1&&xx<NX-2&&yy<NY-2){int i=id(xx,yy);if(!requireWall||wall[i])mask[i]=true;}}}
    private void eraseLine(int x0,int y0,int x1,int y1,int radius){int steps=Math.max(Math.abs(x1-x0),Math.abs(y1-y0));for(int k=0;k<=steps;k++){int x=Math.round(x0+(x1-x0)*k/(float)Math.max(steps,1)),y=Math.round(y0+(y1-y0)*k/(float)Math.max(steps,1));for(int yy=y-radius;yy<=y+radius;yy++)for(int xx=x-radius;xx<=x+radius;xx++)if(xx>1&&yy>1&&xx<NX-2&&yy<NY-2){int i=id(xx,yy);furniture[i]=false;window[i]=false;roomDoor[i]=false;toiletDoor[i]=false;if(!isExteriorBoundary(i))wall[i]=false;}}}
    private boolean isExteriorBoundary(int i){if(!inside[i])return false;int x=i%NX,y=i/NX;return !inside[id(x-1,y)]||!inside[id(x+1,y)]||!inside[id(x,y-1)]||!inside[id(x,y+1)];}
    public Bitmap exportBitmap(){Bitmap b=Bitmap.createBitmap(Math.max(1,getWidth()),Math.max(1,getHeight()),Bitmap.Config.ARGB_8888);draw(new Canvas(b));return b;}
}
