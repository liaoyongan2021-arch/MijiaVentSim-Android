package com.liaoyongan.mijiaventsim;

import java.util.Arrays;
import java.util.Locale;

/** D2Q9 BGK flow solver with a passive pollutant scalar. */
public final class LbmSolver {
    private static final int[] CX = {0, 1, 0, -1, 0, 1, -1, -1, 1};
    private static final int[] CY = {0, 0, 1, 0, -1, 1, 1, -1, -1};
    private static final int[] OPP = {0, 3, 4, 1, 2, 7, 8, 5, 6};
    private static final double[] W = {4.0/9, 1.0/9, 1.0/9, 1.0/9, 1.0/9,
            1.0/36, 1.0/36, 1.0/36, 1.0/36};

    public final int nx, ny, n;
    public final double[] rho, ux, uy, pollutant;
    private double[][] f, streamed;
    private final double[] nextPollutant;
    private boolean[] solid, inside;
    private double initialMass = 1;
    public double timeSeconds = 0;
    public int environmentMode = 0;
    public double outdoorSpeed = 0.5, outdoorAngle = 0;
    public double fanX = 0.55, fanY = 0.55, fanAngle = 0;
    public int fanLevel = 70;
    public boolean oscillating = true;
    public double sweepDegrees = 140, oscillationPeriod = 20;

    public LbmSolver(int nx, int ny) {
        this.nx = nx; this.ny = ny; this.n = nx * ny;
        rho = new double[n]; ux = new double[n]; uy = new double[n];
        pollutant = new double[n]; nextPollutant = new double[n];
        f = new double[9][n]; streamed = new double[9][n];
        solid = new boolean[n]; inside = new boolean[n];
    }

    private int id(int x, int y) { return y * nx + x; }

    public void reset(boolean[] newSolid, boolean[] newInside) {
        solid = Arrays.copyOf(newSolid, n);
        inside = Arrays.copyOf(newInside, n);
        Arrays.fill(rho, 1.0); Arrays.fill(ux, 0); Arrays.fill(uy, 0);
        for (int i = 0; i < n; i++) pollutant[i] = inside[i] && !solid[i] ? 1.0 : 0.0;
        for (int q = 0; q < 9; q++) Arrays.fill(f[q], W[q]);
        initialMass = 0;
        for (int i = 0; i < n; i++) if (inside[i] && !solid[i]) initialMass += pollutant[i];
        initialMass = Math.max(initialMass, 1e-12);
        timeSeconds = 0;
    }

    public double currentFanAngle() {
        if (!oscillating || sweepDegrees <= 0) return fanAngle;
        double p = (timeSeconds / Math.max(oscillationPeriod, 1)) % 1.0;
        double triangle = 1.0 - 4.0 * Math.abs(p - 0.5);
        return fanAngle + 0.5 * sweepDegrees * triangle;
    }

    public void step(int count) {
        for (int k = 0; k < count; k++) {
            stepFlow();
            // Match the desktop model's unresolved-mixing acceleration.
            for (int scalarSubstep = 0; scalarSubstep < 6; scalarSubstep++) stepScalar();
        }
    }

    private void stepFlow() {
        final double omega = 1.0 / 0.58;
        double fanA = Math.toRadians(currentFanAngle());
        double fdx = Math.cos(fanA), fdy = -Math.sin(fanA);
        double fx0 = fanX * (nx - 1), fy0 = fanY * (ny - 1);
        double forceMagnitude = 0.00055 * Math.pow(Math.max(0, Math.min(100, fanLevel)) / 100.0, 0.7);

        double[] forceX = new double[n], forceY = new double[n];
        for (int y = 0; y < ny; y++) for (int x = 0; x < nx; x++) {
            int i = id(x, y);
            if (solid[i]) continue;
            double rrX = x - fx0, rrY = y - fy0;
            double axial = rrX * fdx + rrY * fdy;
            double lateral = -rrX * fdy + rrY * fdx;
            double length = Math.max(3.5, 0.035 * Math.min(nx, ny));
            double width = Math.max(2.0, 0.018 * Math.min(nx, ny));
            double env = Math.exp(-(axial * axial / (length * length) + lateral * lateral / (width * width)));
            if (Math.abs(axial) > 2.2 * length) env = 0;
            forceX[i] = forceMagnitude * env * fdx;
            forceY[i] = forceMagnitude * env * fdy;
        }

        double[][] post = new double[9][n];
        for (int i = 0; i < n; i++) {
            if (solid[i]) { rho[i] = 1; ux[i] = uy[i] = 0; continue; }
            double density = 0, mx = 0, my = 0;
            for (int q = 0; q < 9; q++) {
                density += f[q][i]; mx += f[q][i] * CX[q]; my += f[q][i] * CY[q];
            }
            density = Math.max(density, 1e-8);
            double vx = mx / density + 0.5 * forceX[i] / density;
            double vy = my / density + 0.5 * forceY[i] / density;
            double speed = Math.hypot(vx, vy);
            if (speed > 0.12) { vx *= 0.12 / speed; vy *= 0.12 / speed; }
            rho[i] = density; ux[i] = vx; uy[i] = vy;
            double u2 = vx * vx + vy * vy;
            for (int q = 0; q < 9; q++) {
                double cu = CX[q] * vx + CY[q] * vy;
                double feq = W[q] * density * (1 + 3 * cu + 4.5 * cu * cu - 1.5 * u2);
                post[q][i] = f[q][i] - omega * (f[q][i] - feq)
                        + 3 * W[q] * (CX[q] * forceX[i] + CY[q] * forceY[i]);
            }
        }

        for (int q = 0; q < 9; q++) Arrays.fill(streamed[q], 0);
        for (int y = 1; y < ny - 1; y++) for (int x = 1; x < nx - 1; x++) {
            int i = id(x, y); if (solid[i]) continue;
            for (int q = 0; q < 9; q++) {
                int j = id(x + CX[q], y + CY[q]);
                if (solid[j]) streamed[OPP[q]][i] += post[q][i];
                else streamed[q][j] = post[q][i];
            }
        }
        setOuterBoundary(streamed);
        double[][] temp = f; f = streamed; streamed = temp;
        timeSeconds += 0.10;
    }

    private void setOuterBoundary(double[][] target) {
        double speed;
        if (environmentMode == 0) speed = 0;
        else if (environmentMode == 2) speed = Math.max(0.15, Math.min(outdoorSpeed, 0.8));
        else speed = Math.max(0, outdoorSpeed);
        double lattice = Math.min(speed / 80.0, 0.075);
        double a = Math.toRadians(outdoorAngle);
        double vx = lattice * Math.cos(a), vy = -lattice * Math.sin(a);
        double u2 = vx * vx + vy * vy;
        for (int y = 0; y < ny; y++) for (int x = 0; x < nx; x++) {
            if (x > 1 && x < nx - 2 && y > 1 && y < ny - 2) continue;
            int i = id(x, y);
            for (int q = 0; q < 9; q++) {
                double cu = CX[q] * vx + CY[q] * vy;
                target[q][i] = W[q] * (1 + 3 * cu + 4.5 * cu * cu - 1.5 * u2);
            }
        }
    }

    private void stepScalar() {
        final double diffusion = 0.018;
        for (int y = 1; y < ny - 1; y++) for (int x = 1; x < nx - 1; x++) {
            int i = id(x, y);
            if (solid[i]) { nextPollutant[i] = 0; continue; }
            int l = id(x - 1, y), r = id(x + 1, y), t = id(x, y - 1), b = id(x, y + 1);
            double cc = pollutant[i];
            double cl = solid[l] ? cc : pollutant[l], cr = solid[r] ? cc : pollutant[r];
            double ct = solid[t] ? cc : pollutant[t], cb = solid[b] ? cc : pollutant[b];
            double dcdx = ux[i] >= 0 ? cc - cl : cr - cc;
            double dcdy = uy[i] >= 0 ? cc - ct : cb - cc;
            double value = cc - ux[i] * dcdx - uy[i] * dcdy
                    + diffusion * (cl + cr + ct + cb - 4 * cc);
            nextPollutant[i] = Math.max(0, Math.min(1, value));
        }
        // Exterior is a large clean-air reservoir. Flow is solved outside,
        // while pollutant leaving through an opening cannot recirculate from
        // the finite numerical buffer.
        for (int i = 0; i < n; i++) if (!inside[i]) nextPollutant[i] = 0;
        System.arraycopy(nextPollutant, 0, pollutant, 0, n);
    }

    public double pollutantPercent() {
        double mass = 0;
        for (int i = 0; i < n; i++) if (inside[i] && !solid[i]) mass += pollutant[i];
        return 100.0 * mass / initialMass;
    }

    public double physicalSpeed(int i) { return Math.hypot(ux[i], uy[i]) * 80.0; }

    /** Host-side numerical smoke test; ignored by Android runtime. */
    public static void main(String[] args) {
        int nx=140,ny=100; boolean[] in=new boolean[nx*ny],s=new boolean[nx*ny];
        for(int y=20;y<=80;y++)for(int x=30;x<=110;x++)in[y*nx+x]=true;
        for(int y=20;y<=80;y++){s[y*nx+30]=true;s[y*nx+110]=true;}
        for(int x=30;x<=110;x++){s[20*nx+x]=true;s[80*nx+x]=true;}
        for(int y=45;y<=56;y++)s[y*nx+110]=false;
        LbmSolver q=new LbmSolver(nx,ny);q.fanX=0.48;q.fanY=0.52;q.fanAngle=0;q.oscillating=false;q.fanLevel=100;q.reset(s,in);
        int steps=args.length>0?Integer.parseInt(args[0]):300;
        for(int k=0;k<steps;k++)q.step(1);
        double max=0;for(int i=0;i<q.n;i++)max=Math.max(max,Math.hypot(q.ux[i],q.uy[i]));
        System.out.printf(Locale.US,"time=%.1f maxU=%.5f pollutant=%.3f%%%n",q.timeSeconds,max,q.pollutantPercent());
        if(!Double.isFinite(max)||max>=0.3||q.pollutantPercent()>=100)throw new IllegalStateException("LBM smoke test failed");
    }
}
