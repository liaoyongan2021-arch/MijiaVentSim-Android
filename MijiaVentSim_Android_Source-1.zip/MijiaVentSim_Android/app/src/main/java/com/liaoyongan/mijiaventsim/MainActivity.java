package com.liaoyongan.mijiaventsim;

import android.app.Activity;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity implements SimulationView.StateListener {
    private SimulationView simulation;
    private TextView timeText;
    private TextView pollutantText;
    private TextView toolText;
    private Button runButton;

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private TextView label(String text, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setPadding(dp(8), dp(7), dp(8), dp(7));
        return v;
    }

    private Button button(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(dp(46));
        b.setOnClickListener(listener);
        b.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(50)));
        return b;
    }

    private TextView section(String text) {
        TextView v = label(text, 15, Color.rgb(25, 57, 72));
        v.setBackgroundColor(Color.rgb(218, 230, 236));
        v.setTypeface(null, 1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(8), 0, dp(4));
        v.setLayoutParams(lp);
        return v;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(234, 240, 243));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(Color.rgb(238, 243, 246));
        root.setPadding(dp(8), dp(8), dp(8), dp(8));

        simulation = new SimulationView(this);
        simulation.setStateListener(this);
        root.addView(makeLeftPanel(), new LinearLayout.LayoutParams(dp(238), -1));
        root.addView(makeCenterPanel(), new LinearLayout.LayoutParams(0, -1, 1f));
        root.addView(makeRightPanel(), new LinearLayout.LayoutParams(dp(292), -1));
        setContentView(root);
    }

    private View makeLeftPanel() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), 0, dp(8), 0);
        box.addView(section("1. 正交外墙轮廓"));
        box.addView(label("依次选择方向并输入实际墙长；相邻墙段必须垂直。", 12, Color.DKGRAY));
        Spinner direction = new Spinner(this);
        String[] directions = {"向右", "向上", "向左", "向下"};
        direction.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, directions));
        box.addView(direction, new LinearLayout.LayoutParams(-1, dp(48)));
        EditText lengthInput = new EditText(this);
        lengthInput.setHint("墙长（m）"); lengthInput.setText("4.0");
        lengthInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        box.addView(lengthInput, new LinearLayout.LayoutParams(-1, dp(50)));
        TextView outlineStatus = label("当前点：(0.00, 0.00) m", 12, Color.rgb(65, 78, 86));
        box.addView(outlineStatus);
        box.addView(button("重新绘制外墙", v -> {
            simulation.startOutline(); outlineStatus.setText("当前点：(0.00, 0.00) m");
        }));
        box.addView(button("添加垂直墙段", v -> {
            try {
                float length = Float.parseFloat(lengthInput.getText().toString());
                String result = simulation.addOutlineSegment(direction.getSelectedItem().toString(), length);
                outlineStatus.setText(result);
                if (result.contains("必须")) Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException ex) {
                Toast.makeText(this, "请输入正确的墙长", Toast.LENGTH_SHORT).show();
            }
        }));
        box.addView(button("自动闭合并生成房间", v -> {
            String result = simulation.autoCloseOutline(); outlineStatus.setText(result);
            Toast.makeText(this, result, Toast.LENGTH_SHORT).show();
        }));

        box.addView(section("2. 门窗、隔墙与家具"));
        toolText = label("当前工具：风扇", 13, Color.DKGRAY);
        box.addView(toolText);
        String[][] tools = {
                {"风扇位置与方向", "FAN"}, {"墙壁 / 隔墙", "WALL"},
                {"窗户", "WINDOW"}, {"房门", "ROOM_DOOR"},
                {"厕所门", "TOILET_DOOR"}, {"家具障碍物", "FURNITURE"},
                {"橡皮擦", "ERASER"}
        };
        for (String[] item : tools) {
            box.addView(button(item[0], v -> {
                simulation.setTool(item[1]);
                toolText.setText("当前工具：" + ((Button) v).getText());
            }));
        }
        box.addView(section("画布操作"));
        box.addView(label("单指拖动绘制；风扇工具下拖出送风方向。双指缩放，双指中心移动画布。", 12, Color.DKGRAY));
        box.addView(button("恢复适合窗口", v -> simulation.fitView()));
        box.addView(button("恢复示例房间", v -> simulation.defaultLayout()));
        scroll.addView(box);
        return scroll;
    }

    private View makeCenterPanel() {
        LinearLayout center = new LinearLayout(this);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setPadding(dp(4), 0, dp(4), 0);

        LinearLayout modes = new LinearLayout(this);
        modes.setGravity(Gravity.CENTER_VERTICAL);
        modes.addView(label("显示：", 14, Color.rgb(35, 58, 70)));
        Spinner spinner = new Spinner(this);
        String[] items = {"污染物", "速度", "矢量", "污染物衰减曲线"};
        spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items));
        spinner.setOnItemSelectedListener(new SimpleItemSelectedListener(position -> simulation.setDisplayMode(position)));
        modes.addView(spinner, new LinearLayout.LayoutParams(dp(190), dp(50)));
        Button minus = button("－", v -> simulation.zoomBy(0.82f));
        Button plus = button("＋", v -> simulation.zoomBy(1.22f));
        modes.addView(minus, new LinearLayout.LayoutParams(dp(60), dp(48)));
        modes.addView(plus, new LinearLayout.LayoutParams(dp(60), dp(48)));
        center.addView(modes, new LinearLayout.LayoutParams(-1, dp(52)));

        center.addView(simulation, new LinearLayout.LayoutParams(-1, 0, 1f));
        TextView legend = label("污染物：蓝色低 → 红色高　　速度：深蓝低 → 黄色高　　黑：墙　灰：家具　青：窗　绿：开启门　棕：关闭门", 12, Color.rgb(55, 72, 80));
        legend.setGravity(Gravity.CENTER);
        center.addView(legend, new LinearLayout.LayoutParams(-1, dp(38)));
        return center;
    }

    private View makeRightPanel() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), 0, dp(4), 0);

        box.addView(section("计算控制"));
        runButton = button("开始计算", v -> {
            simulation.setRunning(!simulation.isRunning());
            runButton.setText(simulation.isRunning() ? "暂停计算" : "开始计算");
        });
        box.addView(runButton);
        box.addView(button("重置污染物为 100%", v -> {
            simulation.resetSimulation(); runButton.setText("开始计算");
        }));
        timeText = label("等效时间：0.0 s", 15, Color.rgb(35, 58, 70));
        pollutantText = label("室内污染物：100.0%", 15, Color.rgb(178, 64, 43));
        box.addView(timeText);
        box.addView(pollutantText);

        box.addView(section("米家落地扇 1X"));
        TextView powerText = label("挡位：70 / 100", 13, Color.DKGRAY);
        box.addView(powerText);
        SeekBar power = new SeekBar(this);
        power.setMax(99); power.setProgress(69);
        power.setOnSeekBarChangeListener(new SimpleSeekListener(value -> {
            simulation.setFanPower(value + 1);
            powerText.setText("挡位：" + (value + 1) + " / 100");
        }));
        box.addView(power);
        TextView angleText = label("方向：0°", 13, Color.DKGRAY);
        box.addView(angleText);
        SeekBar angle = new SeekBar(this);
        angle.setMax(360); angle.setProgress(180);
        angle.setOnSeekBarChangeListener(new SimpleSeekListener(value -> {
            int degree = value - 180;
            simulation.setFanAngle(degree);
            angleText.setText("方向：" + degree + "°");
        }));
        box.addView(angle);
        Switch oscillate = new Switch(this);
        oscillate.setText("左右摇头 140°"); oscillate.setChecked(true);
        oscillate.setOnCheckedChangeListener((b, checked) -> simulation.setOscillating(checked));
        box.addView(oscillate);

        box.addView(section("门与室外环境"));
        Switch roomDoor = new Switch(this);
        roomDoor.setText("房门开启（默认关闭）");
        roomDoor.setOnCheckedChangeListener((b, checked) -> simulation.setRoomDoorOpen(checked));
        box.addView(roomDoor);
        Switch toiletDoor = new Switch(this);
        toiletDoor.setText("厕所门开启"); toiletDoor.setChecked(true);
        toiletDoor.setOnCheckedChangeListener((b, checked) -> simulation.setToiletDoorOpen(checked));
        box.addView(toiletDoor);
        Spinner env = new Spinner(this);
        String[] envs = {"静止室外，仅风扇", "室外来风", "自然弱背景风"};
        env.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, envs));
        env.setOnItemSelectedListener(new SimpleItemSelectedListener(simulation::setEnvironmentMode));
        box.addView(env, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView windSpeedText = label("室外风速：0.5 m/s", 13, Color.DKGRAY);
        box.addView(windSpeedText);
        SeekBar windSpeed = new SeekBar(this); windSpeed.setMax(60); windSpeed.setProgress(10);
        windSpeed.setOnSeekBarChangeListener(new SimpleSeekListener(value -> {
            double speed = value * 0.05; simulation.setOutdoorSpeed(speed);
            windSpeedText.setText(String.format(Locale.CHINA, "室外风速：%.2f m/s", speed));
        }));
        box.addView(windSpeed);
        TextView windAngleText = label("室外风向：0°", 13, Color.DKGRAY);
        box.addView(windAngleText);
        SeekBar windAngle = new SeekBar(this); windAngle.setMax(360); windAngle.setProgress(180);
        windAngle.setOnSeekBarChangeListener(new SimpleSeekListener(value -> {
            int degree = value - 180; simulation.setOutdoorAngle(degree);
            windAngleText.setText("室外风向：" + degree + "°");
        }));
        box.addView(windAngle);

        box.addView(section("输出"));
        box.addView(button("导出当前视图 PNG", v -> exportPng()));
        box.addView(label("Android 首个测试版先验证平板布局与计算稳定性；GIF 清除动画将在测试版通过后接入。", 12, Color.rgb(115, 75, 32)));
        scroll.addView(box);
        return scroll;
    }

    private void exportPng() {
        try {
            Bitmap bitmap = simulation.exportBitmap();
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "MijiaVentSim_" + stamp + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MijiaVentSim");
            android.net.Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IllegalStateException("无法创建图片文件");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, output);
            }
            Toast.makeText(this, "已保存到 图片/MijiaVentSim", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "导出失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onState(double time, double pollutant) {
        runOnUiThread(() -> {
            timeText.setText(String.format(Locale.CHINA, "等效时间：%.1f s", time));
            pollutantText.setText(String.format(Locale.CHINA, "室内污染物：%.1f%%", pollutant));
        });
    }

    private static class SimpleSeekListener implements SeekBar.OnSeekBarChangeListener {
        interface Callback { void changed(int value); }
        private final Callback callback;
        SimpleSeekListener(Callback callback) { this.callback = callback; }
        public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) { callback.changed(progress); }
        public void onStartTrackingTouch(SeekBar bar) {}
        public void onStopTrackingTouch(SeekBar bar) {}
    }

    private static class SimpleItemSelectedListener implements android.widget.AdapterView.OnItemSelectedListener {
        interface Callback { void selected(int position); }
        private final Callback callback;
        SimpleItemSelectedListener(Callback callback) { this.callback = callback; }
        public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { callback.selected(pos); }
        public void onNothingSelected(android.widget.AdapterView<?> p) {}
    }
}
